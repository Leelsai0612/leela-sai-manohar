<html>
<body style=" background-image: url(adminlogin.jpeg);
    height: 100%; 
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
<div align="center">
<?php 

echo " <br><a href=\"http://localhost/railway/insert_into_stations.php\"> Show All Station </a><br> ";
echo " <br><a href=\"http://localhost/railway/insert_into_train_1.php\"> Enter New Train </a><br> ";
echo " <br><a href=\"http://localhost/railway/insert_into_classseats_1.php\"> Enter Train Schedule </a><br> ";
echo " <br><a href=\"http://localhost/railway/booked.php\"> View all booked tickets </a><br> ";
echo " <br><a href=\"http://localhost/railway/cancelled.php\"> View all cancelled tickets </a><br> ";

?>
<br><a href="http://localhost/railway/index.htm">Go to Home Page!!! </a> You'll be Logged Out!!!
</div>
</body>
</html>

